import { useState, useEffect } from 'react';
import { Navbar, type NavKey } from './components/Navbar/Navbar';
import LoginPage from './page/Login.page';
import SignupPage from './page/Signup.page'; // Ensure this path points to your Signup view
import HomePage from './page/Home.page';
import { useAuth } from './context/AuthContext';

function App() {
  // 1. Extend state typing locally so it can hold "signup" alongside your NavKeys
  const [activeTab, setActiveTab] = useState<NavKey | "signup">("home");
  const { isAuthenticated } = useAuth();

  // Redirect to home if logged in while viewing auth screens
  useEffect(() => {
    if (isAuthenticated && (activeTab === "auth" || activeTab === "signup")) {
      setActiveTab("home");
    }
  }, [isAuthenticated, activeTab]);

  const renderBodyContent = () => {
    switch (activeTab) {
      case "auth":
        return (
          <LoginPage 
            onCancel={() => setActiveTab("home")} 
            onNavigateToSignup={() => setActiveTab("signup")} // 2. Connect the link callback to flip view state
          />
        );
      
      case "signup":
        // 3. Mount your registration profile view
        return (
          <SignupPage 
            onCancel={() => setActiveTab("auth")} // Goes back to login screen if they hit cancel
          />
        );

      case "home":
        return <HomePage onShopNow={() => setActiveTab("shopping")} />;
      default:
        return (
          <div className="p-8 text-center text-text-muted font-body">
            Content for <span className="capitalize font-bold text-brand-red">{activeTab}</span> section coming soon!
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-bg-main text-text-main transition-colors duration-200">
      {/* We typecast activeTab to NavKey for the Navbar since it doesn't need to know about the secret signup view */}
      <Navbar activeTab={activeTab as NavKey} setActiveTab={setActiveTab} />
      
      <main className="w-full">
        {renderBodyContent()}
      </main>
    </div>
  );
}

export default App;
