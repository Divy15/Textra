import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home,
  Phone,
  LogIn,
  Sun,
  Moon,
  ShoppingBag,
  User,
} from "lucide-react";
import { useTheme } from "../../context/ThemeContext";
import { useAuth } from "../../context/AuthContext";

export type NavKey = "home" | "contact" | "auth" | "shopping";

interface NavItem {
  key: NavKey;
  title: Record<"en" | "gu", string>;
  icon: React.ComponentType<any>;
}

const NAV_ITEMS: NavItem[] = [
  { key: "home", title: { en: "Home", gu: "ઘર" }, icon: Home },
  { key: "contact", title: { en: "Contact", gu: "સંપર્ક" }, icon: Phone },
  { key: "shopping", title: { en: "Shopping", gu: "ખરીદી" }, icon: ShoppingBag },
  { key: "auth", title: { en: "Login", gu: "લોગઇન" }, icon: LogIn },
];

interface NavbarProps {
  activeTab: NavKey;
  setActiveTab: (tab: NavKey) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated, logout } = useAuth();

  const [lang] = useState<"en" | "gu">("en");
  const [expandedIcon, setExpandedIcon] = useState<NavKey | null>("home");

  return (
    <header className="w-full bg-bg-main border-b border-border-main text-text-main relative z-50">
      
      {/* ====================================================================== */}
      {/* 1. DESKTOP & LAPTOP & TABLET VIEWPORT (xl and above) */}
      {/* ====================================================================== */}
      <div className="hidden xl:grid grid-cols-3 items-center px-8 py-5 max-w-7xl mx-auto">
        
        {/* Left Links */}
        <div className="flex items-center space-x-8 font-body text-xs uppercase tracking-widest font-medium">
          {NAV_ITEMS.map((item) => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.key;
            
            return (
              <button
                key={item.key}
                onClick={() => setActiveTab(item.key)}
                className={`relative py-1 cursor-pointer transition ${
                  isActive ? "text-brand-red font-bold" : "text-text-muted hover:text-text-main"
                }`}
              >
                <div className="flex items-center">
                  <span className="pr-2">
                    <IconComponent size={14} />
                  </span>
                  {item.title[lang]}
                  
                  {isActive && (
                    <motion.div
                      layoutId="desktopUnderline"
                      className="absolute bottom-0 left-0 w-full h-[1.5px] bg-brand-red"
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Center Traditional Branding */}
        <div className="text-center">
          <h1 className="font-header text-2xl lg:text-3xl font-bold tracking-wider text-brand-red whitespace-nowrap">
            Paresh Bandhani Ghar<span className="text-brand-yellow">.</span>
          </h1>
          <span className="text-[10px] font-body tracking-[0.4em] uppercase text-brand-yellow block mt-0.5">
            Heritage Gujarati Bandhani
          </span>
        </div>

        {/* Right Utilities (Theme, Profile) */}
        <div className="flex items-center justify-end space-x-6 font-body text-sm">
          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-full border border-border-main hover:bg-brand-yellow/10 transition cursor-pointer"
          >
            {theme === "light" ? <Moon size={16} /> : <Sun size={16} />}
          </button>

          {isAuthenticated ? (
            <div className="flex items-center space-x-3 pl-2 border-l border-border-main">
              <span className="text-xs font-semibold text-brand-yellow">
                {user?.username.split(" ")[0]}
              </span>
              <button
                onClick={() => {
                  logout();
                  setActiveTab("home");
                }}
                className="text-xs text-brand-red underline uppercase tracking-wider cursor-pointer"
              >
                Logout
              </button>
            </div>
          ) : (
            <User
              size={16}
              className="text-text-muted hover:text-brand-red transition cursor-pointer"
              onClick={() => setActiveTab("auth")}
            />
          )}
        </div>
      </div>

      {/* ====================================================================== */}
      {/* 2. MOBILE VIEWPORT OVERALL HEADER CONTAINER (Below xl) */}
      {/* ====================================================================== */}
      <div className="xl:hidden flex flex-col w-full">
        
        {/* Core Mobile Banner Line */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-border-main/50">
          <div>
            <h1 className="font-header text-2xl font-bold tracking-wide text-brand-red">
              Paresh Bandhani Ghar<span className="text-brand-yellow">.</span>
            </h1>
            <span className="text-[10px] font-body tracking-[0.4em] uppercase text-brand-yellow block mt-0.5">
              Heritage Gujarati Bandhani
            </span>
          </div>

          {isAuthenticated && (
            <span className="text-xs font-semibold text-brand-yellow px-2 py-1 bg-brand-yellow/10 rounded-sm">
              {user?.username.split(" ")[0]}
            </span>
          )}
        </div>

        {/* MOBILE horizontal dock */}
        <div className="w-full bg-brand-black/5 dark:bg-brand-cream/5 px-4 py-2 flex items-center justify-between overflow-x-auto gap-4">
          
          <div className="flex items-center gap-1.5 bg-bg-main p-1 rounded-full border border-border-main shadow-sm">
            {NAV_ITEMS.map((item) => {
              const IconComponent = item.icon;
              const isExpanded = expandedIcon === item.key;
              const isActive = activeTab === item.key;

              return (
                <motion.button
                  key={item.key}
                  layout
                  onClick={() => {
                    setExpandedIcon(item.key);
                    setActiveTab(item.key);
                  }}
                  onMouseEnter={() => setExpandedIcon(item.key)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all cursor-pointer text-xs font-body font-medium ${
                    isActive ? "bg-brand-red text-white" : "text-text-muted hover:bg-border-main"
                  }`}
                  transition={{ type: "spring", damping: 25, stiffness: 220 }}
                >
                  <IconComponent size={14} />

                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.span
                        initial={{ width: 0, opacity: 0 }}
                        animate={{ width: "auto", opacity: 1 }}
                        exit={{ width: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden whitespace-nowrap"
                      >
                        {item.title[lang]}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </motion.button>
              );
            })}
          </div>

          <div className="flex items-center justify-end pl-2">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full border border-border-main bg-bg-main shadow-sm text-text-muted cursor-pointer"
            >
              {theme === "light" ? <Moon size={16} /> : <Sun size={16} />}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};