import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { type BaseComponentProps } from '../../types/CommonComponents.ts';

interface InputProps extends BaseComponentProps, Omit<React.InputHTMLAttributes<HTMLInputElement>, 'name' | 'type'> {
  type?: 'text' | 'email' | 'password' | 'url' | 'tel';
}

export const Input: React.FC<InputProps> = ({
  label,
  name,
  placeholder,
  error,
  type = 'text',
  layout = 'col',
  className = '',
  ...rest
}) => {
  const isRow = layout === 'row';

  return (
    <div className={`flex ${isRow ? 'flex-row items-center gap-4' : 'flex-col gap-1.5'} w-full ${className}`}>
      {label && (
        <label htmlFor={name} className={`text-sm font-medium text-gray-700 ${isRow ? 'w-1/3 text-right' : 'w-full'}`}>
          {label}
        </label>
      )}
      
      <div className={`flex flex-col flex-1 w-full relative`}>
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 transition-colors duration-200
            ${error ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-200 focus:border-blue-500'}
          `}
          {...rest}
        />
        
        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="text-xs text-red-500 mt-1 absolute -bottom-5 left-0"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};