import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { type BaseComponentProps } from '../../types/CommonComponents.ts';

// CRITICAL: Ensure you are omitting from TextareaHTMLAttributes, NOT InputHTMLAttributes
interface TextareaProps extends BaseComponentProps, Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'name'> {}

export const Textarea: React.FC<TextareaProps> = ({
  label,
  name,
  placeholder,
  error,
  layout = 'col',
  rows = 4,
  className = '',
  ...rest // This safely gathers ONLY textarea-specific props now
}) => {
  const isRow = layout === 'row';

  return (
    <div className={`flex ${isRow ? 'flex-row items-start gap-4' : 'flex-col gap-1.5'} w-full ${className}`}>
      {label && (
        <label htmlFor={name} className={`text-sm font-medium text-gray-700 ${isRow ? 'w-1/3 text-right pt-2' : 'w-full'}`}>
          {label}
        </label>
      )}

      <div className="flex flex-col flex-1 w-full relative">
        <textarea
          id={name}
          name={name}
          rows={rows}
          placeholder={placeholder}
          className={`w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 transition-colors duration-200 resize-y
            ${error ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-200 focus:border-blue-500'}
          `}
          {...rest} // Re-applies safe HTMLTextAreaElement properties (like its native onChange)
        />

        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="text-xs text-red-500 mt-1 absolute -bottom-5 left-0"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};